import { Link, useMatch, useResolvedPath } from "react-router-dom"

export interface props1 {
    to?: any;
    children?: any; }

export default function Navbar() {
  return (
    <nav className="nav">
      <Link to="/" className="site-title">
        CyberAware
      </Link>
      <ul>
        <CustomLink to="/userguide">User Guide</CustomLink>
        <CustomLink to="/cyberthreats">Cyber Threats</CustomLink>
        <CustomLink to="/solutions">Solutions</CustomLink>
        <CustomLink to="/report">Report A Problem</CustomLink>
        <CustomLink to="/login">Login</CustomLink>
        <CustomLink to="/about">About Us</CustomLink>
      </ul>
    </nav>
  )
}

function CustomLink({ to, children, ...props}: props1) {
  const resolvedPath = useResolvedPath(to)
  const isActive = useMatch({ path: resolvedPath.pathname, end: true })

  return (
    <li className={isActive ? "active" : ""}>
      <Link to={to} {...props}>
        {children}
      </Link>
    </li>
  )
}
