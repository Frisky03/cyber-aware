import Navbar from "./Navbar"
import Home from "./pages/Home"
import AboutUs from "./pages/AboutUs"
import { Route, Routes } from "react-router-dom"
import UserGuide from "./pages/UserGuide"
import CyberThreats from "./pages/CyberThreats"
import Solutions from "./pages/Solutions"
import Login from "./pages/Login"
import Report from "./pages/Report"


function App() {
  return (
    <>
      <Navbar />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/userguide" element={<UserGuide />} />
          <Route path="/cyberthreats" element={<CyberThreats />} />
          <Route path="/solutions" element={<Solutions />} />
          <Route path="/report" element={<Report />} />
          <Route path="/login" element={<Login />} />
          <Route path="/about" element={<AboutUs />} />
        </Routes>
      </div>
    </>
  )
}

export default App
