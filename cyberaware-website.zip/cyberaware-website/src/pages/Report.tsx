export default function Report() {
    return <h1>Report</h1>
  }