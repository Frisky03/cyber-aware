export default function UserGuide() {
    return <h1>User Guide</h1>
  }