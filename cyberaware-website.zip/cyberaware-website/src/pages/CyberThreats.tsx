import "./cyberthreats.css"
export default function CyberThreats() {
    return (
      <div className="cyberthreats">
      <h1>Cyber Threats</h1>
      
      <h2>MALWARE</h2>

      <h2>MALWARE</h2>

      <h2>MALWARE</h2>

      <h2>MALWARE</h2>
      </div>
    )
  }