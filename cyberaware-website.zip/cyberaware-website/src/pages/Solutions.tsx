import "./solutions.css"

export default function Solutions() {
    return (
      <>
      <h1>Solutions</h1>

      <h2>Malware</h2>

      <h2>Phishing</h2>

      <h2>Password Attacks</h2>

      <h2>Ransomware</h2>
      </>
    )
  }