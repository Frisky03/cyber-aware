import './home.css';
import { Button, Typography } from '@mui/material'
import light from './light-bulb.png';
import guide from './guide.png';
import glass from './magnifying-glass.png';
import { Link } from 'react-router-dom';

export default function Home() {
  return(
    <div className="App">

      <div className= "header">
      <Typography variant="h4" style={{fontWeight:'bold'}} color="white">
      KNOW HOW TO RESPOND AGAINST CYBER THREATS
      </Typography>
      </div>

      <div className = "textBody">
      <Typography variant="body1" color="white" >
      Thousands of people are getting scammed every year by scammers in the internet. It happens
      especially to people that does not know how to use their own devices and gets taken advantage 
      and sure, you reading this means that you must know how to respond against those malicious 
      acts right? Well, you know yourself the answer to that but remember, you never know enough the 
      internet and the best course of action for that is to learn more.
      </Typography>
      </div>

      <div className="btn">
      <Link to ="CyberThreats/">
      <Button variant="contained" style={{marginTop:'2rem'}}>VIEW CYBER THREATS</Button>
      </Link>
      </div>

      <div className = "solutions">
        <Typography variant="h6" color="black" style={{fontWeight:'bold'}}>
          SOLUTIONS
        </Typography>
        <div>Learn what to do <br/> against a cyber threat.</div>
        <Link to ="Solutions/">
        <img src={light} alt="light" id="solutionimg"/>
        </Link>
      </div>

      <div className="guide">
      <Typography variant="h6" color="black" style={{fontWeight:'bold'}}>
          USER GUIDE
      </Typography>
      <div>Know how to navigate <br/> around CyberAware.</div>
      <Link to ="UserGuide/">
      <img src={guide} alt="guide" id="userimg"/>
      </Link>
      </div>

      <div className="report">
      <Typography variant="h6" color="black" style={{fontWeight:'bold'}}>
          REPORT A PROBLEM
      </Typography>
      <div>Have any problem? <br/> Report it.</div>
      <Link to = "Report/">
      <img src={glass} alt="glass" id="reportimg"/>
      </Link>
      </div>
      
    </div>
  )
}